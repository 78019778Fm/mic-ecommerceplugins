package APPMIC_E_CommercePlugins_gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppmicECommercePluginsGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppmicECommercePluginsGatewayApplication.class, args);
	}

}
