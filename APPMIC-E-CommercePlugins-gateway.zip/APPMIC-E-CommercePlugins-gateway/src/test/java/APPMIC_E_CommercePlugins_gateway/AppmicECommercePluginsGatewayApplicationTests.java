package APPMIC_E_CommercePlugins_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppmicECommercePluginsGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
